create database bd_aula1;
use bd_aula1;
create table cliente_cli(
id_cliente int auto_increment primary key,
nome_cli varchar(52),
idade_cli int,
sexo_cli varchar(20),
endereco_cli text);
 create table produto(
 id_produto_prod int auto_increment primary key,
 nome va
 );